package com.jets.medicalreminder.medicines;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;

import com.jets.medicalreminder.R;

public class AllMedicinesActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_medicines);
    }

}
